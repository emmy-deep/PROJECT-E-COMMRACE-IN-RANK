<?php
$pageTitle = $pageTitle ?? 'ShopEase';
$loggedUser = user();
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($pageTitle) ?> | ShopEase</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= BASE_URL ?>/assets/style.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top">
<div class="container"><a class="navbar-brand fw-bold text-primary" href="<?= BASE_URL ?>/index.php"><i class="bi bi-bag-heart-fill me-2"></i>ShopEase</a>
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nav">
<ul class="navbar-nav me-auto"><li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/index.php">Home</a></li><li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/index.php#products">Products</a></li></ul>
<div class="d-flex align-items-center gap-3">
<a class="nav-link" href="<?= BASE_URL ?>/cart.php"><i class="bi bi-cart3"></i> Cart <span class="badge bg-primary"><?= array_sum($_SESSION['cart'] ?? []) ?></span></a>
<?php if ($loggedUser): ?>
<span class="small text-muted">Hi, <?= e($loggedUser['name']) ?></span>
<?php if ($loggedUser['role']==='admin'): ?><a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>/admin/index.php">Admin</a><?php else: ?><a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>/my-orders.php">My orders</a><?php endif; ?>
<a class="btn btn-sm btn-dark" href="<?= BASE_URL ?>/logout.php">Logout</a>
<?php else: ?><a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>/login.php">Login</a><a class="btn btn-sm btn-primary" href="<?= BASE_URL ?>/register.php">Sign up</a><?php endif; ?>
</div></div></div></nav>
<main class="container py-4">
