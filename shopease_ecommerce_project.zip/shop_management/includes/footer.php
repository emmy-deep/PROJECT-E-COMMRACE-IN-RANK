</main><footer class="border-top bg-white mt-5 py-4"><div class="container d-flex flex-wrap justify-content-between gap-2 small text-muted"><span>© <?= date('Y') ?> ShopEase. Demo e-commerce project.</span><span>Built with PHP, MySQL & Bootstrap</span></div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>/assets/app.js"></script></body></html>
