CREATE DATABASE IF NOT EXISTS shop_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shop_management;
CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL, role ENUM('admin','customer') NOT NULL DEFAULT 'customer',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE categories (
 id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE
);
CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY, category_id INT NULL, name VARCHAR(180) NOT NULL,
 description TEXT, price DECIMAL(10,2) NOT NULL DEFAULT 0, compare_price DECIMAL(10,2) NULL,
 stock INT NOT NULL DEFAULT 0, image_url VARCHAR(500), active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL
);
CREATE TABLE orders (
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, customer_name VARCHAR(120) NOT NULL,
 phone VARCHAR(30) NOT NULL, address TEXT NOT NULL, total DECIMAL(10,2) NOT NULL,
 status ENUM('Pending','Confirmed','Shipped','Delivered','Cancelled') NOT NULL DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE order_items (
 id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, product_id INT NULL,
 product_name VARCHAR(180) NOT NULL, unit_price DECIMAL(10,2) NOT NULL, quantity INT NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
);
INSERT INTO categories(name) VALUES ('Electronics'),('Fashion'),('Home & Living'),('Accessories');
INSERT INTO products(category_id,name,description,price,compare_price,stock,image_url) VALUES
(1,'Wireless Headphones','Comfortable wireless headphones with clear sound and long battery life.',1499,1999,25,'https://images.unsplash.com/photo-150 type='),
(2,'Everyday Backpack','A versatile backpack for work, college and everyday travel.',899,1199,30,'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=900'),
(3,'Minimal Desk Lamp','Modern desk lamp for a clean and comfortable workspace.',1199,1499,18,'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=900'),
(4,'Classic Wrist Watch','A timeless everyday watch with a minimal design.',2199,2799,12,'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900');
