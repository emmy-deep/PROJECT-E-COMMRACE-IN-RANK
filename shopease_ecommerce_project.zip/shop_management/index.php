<?php
require_once __DIR__.'/config/config.php';
$pageTitle='Discover products';
$q=trim($_GET['q']??''); $cat=(int)($_GET['category']??0);
$sql="SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1";
$args=[];
if($q!==''){ $sql.=" AND (p.name LIKE ? OR p.description LIKE ?)"; $args[]="%$q%";$args[]="%$q%"; }
if($cat){$sql.=" AND p.category_id=?";$args[]=$cat;}
$sql.=" ORDER BY p.created_at DESC";
$stmt=db()->prepare($sql);$stmt->execute($args);$products=$stmt->fetchAll();
$categories=db()->query("SELECT * FROM categories ORDER BY name")->fetchAll();
require __DIR__.'/includes/header.php';
?>
<section class="hero mb-5"><div class="row align-items-center"><div class="col-lg-7"><span class="badge bg-light text-primary mb-3">YOUR EVERYDAY STORE</span><h1 class="display-4">Find something<br>you'll love.</h1><p class="lead">Thoughtful products, clear prices and a simple shopping experience.</p><a href="#products" class="btn btn-light btn-lg text-primary fw-semibold">Explore products <i class="bi bi-arrow-right"></i></a></div><div class="col-lg-5 text-center d-none d-lg-block"><i class="bi bi-bag-heart" style="font-size:11rem;opacity:.9"></i></div></div></section>
<div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-3" id="products"><div><h2 class="section-title mb-1">Popular products</h2><div class="text-muted">Browse our latest collection</div></div>
<form class="d-flex gap-2" method="get"><input class="form-control" name="q" placeholder="Search products..." value="<?=e($q)?>"><select class="form-select" name="category" onchange="this.form.submit()"><option value="0">All categories</option><?php foreach($categories as $c):?><option value="<?=$c['id']?>" <?=$cat===$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach;?></select><button class="btn btn-primary">Search</button></form></div>
<div class="row g-4"><?php foreach($products as $p):?><div class="col-6 col-md-4 col-lg-3"><div class="card product-card"><a href="product.php?id=<?=$p['id']?>"><img class="card-img-top product-image" src="<?=e($p['image_url'] ?: 'https://placehold.co/600x400?text=Product')?>" alt="<?=e($p['name'])?>"></a><div class="card-body"><div class="small text-muted"><?=e($p['category']??'General')?></div><h6 class="mt-1"><a class="text-decoration-none text-dark" href="product.php?id=<?=$p['id']?>"><?=e($p['name'])?></a></h6><div class="price"><?=money($p['price'])?> <?php if($p['compare_price']):?><small class="text-muted text-decoration-line-through fw-normal"><?=money($p['compare_price'])?></small><?php endif;?></div><div class="small text-muted mb-3"><?= $p['stock']>0?'In stock':'Out of stock' ?></div><a class="btn btn-outline-primary btn-sm w-100" href="product.php?id=<?=$p['id']?>">View details</a></div></div></div><?php endforeach;?></div>
<?php if(!$products):?><div class="alert alert-info mt-3">No products found. Try another search.</div><?php endif;?>
<?php require __DIR__.'/includes/footer.php';?>
