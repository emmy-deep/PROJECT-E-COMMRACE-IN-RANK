# ShopEase – PHP + MySQL E-commerce Starter

A beginner-friendly academic project with a customer storefront and admin panel.

## Requirements
- Windows 10/11
- XAMPP with Apache, MySQL and PHP 8+
- Browser and VS Code (optional)

## Run locally
1. Extract the `shop_management` folder into `C:\xampp\htdocs\`.
2. Open XAMPP Control Panel and start **Apache** and **MySQL**.
3. Visit `http://localhost/phpmyadmin`.
4. Select **Import**, choose `shop_management/database.sql`, and run it.
5. Open `shop_management/config/config.php`. Confirm DB settings match your XAMPP MySQL settings. Default XAMPP values are database `shop_management`, user `root`, blank password.
6. Open `http://localhost/shop_management/`.

## Create the first admin account
1. Register a normal customer account using the website.
2. In phpMyAdmin, open the `shop_management` database and run this SQL, replacing the email:
   ```sql
   UPDATE users SET role='admin' WHERE email='you@example.com';
   ```
3. Log out and log in again. The Admin button/dashboard will appear at `/shop_management/admin/`.

## Included
- Customer registration and login (password hashing)
- Product catalogue, search and category filtering
- Product details and quantity-aware cart
- Checkout and order creation (demo / cash-on-delivery only)
- Stock validation and decrement during checkout
- Customer order history
- Admin dashboard, product CRUD, pricing, stock and categories
- Customer list and order management
- Order status transition checks; terminal statuses cannot be changed

## Important limitations
This is a learning/demo starter, not a production-ready commerce platform. It does not process real payments, send emails, upload product images, calculate shipping/tax, or provide advanced audit logs, refunds, returns, or multi-admin permissions. Before public deployment, add HTTPS, secure production secrets, rate limiting, server-side validation hardening, backups, payment gateway integration, privacy/legal pages, and security testing. Change the default database credentials and configure `BASE_URL` if the project is installed in a different folder.
