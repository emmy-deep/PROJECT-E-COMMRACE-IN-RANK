<?php
require_once __DIR__.'/config/config.php';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$s=db()->prepare("SELECT * FROM users WHERE email=?");$s->execute([strtolower(trim($_POST['email']??''))]);$u=$s->fetch();
if($u&&password_verify($_POST['password']??'',$u['password'])){session_regenerate_id(true);$_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];redirect($u['role']==='admin'?'admin/index.php':'index.php');}else $error='Incorrect email or password.';}
$pageTitle='Sign in';require __DIR__.'/includes/header.php';?>
<div class="row justify-content-center"><div class="col-md-6 col-lg-5"><div class="card border-0 p-4"><h2 class="fw-bold">Welcome back</h2><p class="text-muted">Sign in to continue shopping.</p><?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><label class="form-label">Email</label><input class="form-control mb-3" type="email" name="email" required><label class="form-label">Password</label><input class="form-control mb-3" type="password" name="password" required><button class="btn btn-primary w-100">Sign in</button></form><p class="small text-center mt-3">New here? <a href="register.php">Create an account</a></p></div></div></div>
<?php require __DIR__.'/includes/footer.php';?>
