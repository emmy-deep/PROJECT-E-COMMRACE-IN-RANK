<?php
require_once __DIR__.'/config/config.php';verify_csrf();
if($_SERVER['REQUEST_METHOD']==='POST'){foreach(($_POST['qty']??[]) as $id=>$qty){$id=(int)$id;$qty=(int)$qty;if($qty<=0)unset($_SESSION['cart'][$id]);else $_SESSION['cart'][$id]=min(99,$qty);}if(isset($_POST['remove']))unset($_SESSION['cart'][(int)$_POST['remove']]);redirect('cart.php');}
$cart=$_SESSION['cart']??[];$items=[];$total=0;
if($cart){$ids=array_keys($cart);$marks=implode(',',array_fill(0,count($ids),'?'));$s=db()->prepare("SELECT * FROM products WHERE id IN ($marks) AND active=1");$s->execute($ids);$items=$s->fetchAll();}
$pageTitle='Shopping cart';require __DIR__.'/includes/header.php';
?>
<h1 class="section-title mb-4">Your shopping cart</h1>
<?php if(!$items):?><div class="card border-0 p-5 text-center"><i class="bi bi-cart-x fs-1 text-primary"></i><h4 class="mt-3">Your cart is empty</h4><p class="text-muted">Find something you love and add it here.</p><a class="btn btn-primary mx-auto" href="index.php">Continue shopping</a></div><?php else:?>
<form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><div class="card border-0"><div class="table-responsive"><table class="table align-middle mb-0"><thead><tr><th>Product</th><th>Price</th><th style="width:130px">Quantity</th><th>Subtotal</th><th></th></tr></thead><tbody>
<?php foreach($items as $p):$qty=min((int)$cart[$p['id']],(int)$p['stock']);$line=$qty*$p['price'];$total+=$line;?>
<tr><td><div class="d-flex align-items-center gap-3"><img src="<?=e($p['image_url'])?>" width="64" height="64" style="object-fit:cover;border-radius:10px"><strong><?=e($p['name'])?></strong></div></td><td><?=money($p['price'])?></td><td><input class="form-control" type="number" min="0" max="<?=$p['stock']?>" name="qty[<?=$p['id']?>]" value="<?=$qty?>"></td><td class="fw-bold"><?=money($line)?></td><td><button class="btn btn-sm btn-outline-danger" name="remove" value="<?=$p['id']?>"><i class="bi bi-trash"></i></button></td></tr>
<?php endforeach;?></tbody></table></div></div><div class="d-flex flex-wrap justify-content-between align-items-center mt-4 gap-3"><button class="btn btn-outline-secondary">Update cart</button><div class="text-end"><div class="text-muted">Order total</div><div class="fs-3 fw-bold"><?=money($total)?></div><a href="checkout.php" class="btn btn-primary btn-lg mt-2">Proceed to checkout</a></div></div></form><?php endif;?>
<?php require __DIR__.'/includes/footer.php';?>
