<?php
require_once __DIR__.'/config/config.php';
$id=(int)($_GET['id']??0);$s=db()->prepare("SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.active=1");$s->execute([$id]);$p=$s->fetch();
if(!$p){http_response_code(404);exit('Product not found');}
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$qty=max(1,min(20,(int)($_POST['quantity']??1)));if($qty>$p['stock']){$error='Requested quantity is not available.';}else{$_SESSION['cart'][$id]=min($p['stock'],($_SESSION['cart'][$id]??0)+$qty);redirect('cart.php');}}
$pageTitle=$p['name'];require __DIR__.'/includes/header.php';
?>
<div class="row g-5 align-items-start"><div class="col-md-6"><img class="img-fluid rounded-4 bg-white" src="<?=e($p['image_url']?:'https://placehold.co/800x600?text=Product')?>" alt="<?=e($p['name'])?>"></div><div class="col-md-6"><div class="text-muted mb-2"><?=e($p['category']??'General')?></div><h1 class="fw-bold"><?=e($p['name'])?></h1><div class="price fs-3 my-3"><?=money($p['price'])?> <?php if($p['compare_price']):?><small class="fs-6 text-muted text-decoration-line-through fw-normal"><?=money($p['compare_price'])?></small><?php endif;?></div><p class="text-muted"><?=nl2br(e($p['description']))?></p><p><span class="badge <?=$p['stock']?'bg-success':'bg-secondary'?>"><?=$p['stock']?'In stock: '.$p['stock']:'Out of stock'?></span></p>
<?php if(isset($error)):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<form method="post" class="d-flex gap-2 align-items-center mt-4"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="number" name="quantity" class="form-control" style="max-width:100px" min="1" max="<?=max(1,$p['stock'])?>" value="1" <?=$p['stock']?'':'disabled'?>><button class="btn btn-primary btn-lg" <?=$p['stock']?'':'disabled'?>><i class="bi bi-cart-plus me-2"></i>Add to cart</button></form></div></div>
<?php require __DIR__.'/includes/footer.php';?>
